gcc pfcserver.c switch.c utils.c databasetools.c -lcrypto -g3 -lpthread -lssl -lsqlite3 -o server -Wall


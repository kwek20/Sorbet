gcc pfcclient.c switch.c utils.c fileEncrypt.c -l crypto -g3 -lssl -lpthread -o client -Wall
